<?php
if (!defined('ABSPATH')) exit;
class WPAI_Knowledge_Controller {
    public static function init() { add_action('rest_api_init', [__CLASS__, 'routes']); }

    public static function routes() {
        register_rest_route('wp-ai/v1', '/knowledge', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [__CLASS__, 'create'],
            'permission_callback' => function() { return current_user_can('manage_options'); },
        ]);
    }

    public static function create(WP_REST_Request $request) {
        global $wpdb;
        $title = sanitize_text_field($request->get_param('title'));
        $content = wp_kses_post($request->get_param('content'));
        if (!$title || !$content) return new WP_Error('invalid_source', 'Title and content are required.', ['status' => 400]);

        $t = WPAI_Schema::tables();
        $wpdb->insert($t['sources'], [
            'type' => 'text',
            'title' => $title,
            'content' => $content,
            'status' => 'ready',
            'created_at' => current_time('mysql', true),
            'updated_at' => current_time('mysql', true),
        ]);
        $source_id = (int)$wpdb->insert_id;

        $plain = wp_strip_all_tags($content);
        $chunks = preg_split('/\s+/', trim($plain));
        $size = 180;
        for ($i = 0, $n = count($chunks); $i < $n; $i += $size) {
            $chunk = implode(' ', array_slice($chunks, $i, $size));
            if (!$chunk) continue;
            $wpdb->insert($t['chunks'], [
                'source_id' => $source_id,
                'chunk_index' => (int)floor($i / $size),
                'content' => $chunk,
                'hash' => hash('sha256', $chunk),
                'created_at' => current_time('mysql', true),
            ]);
        }
        WPAI_AuditLogger::log('knowledge_created', 'source', $source_id);
        return new WP_REST_Response(['success' => true, 'id' => $source_id], 201);
    }
}
