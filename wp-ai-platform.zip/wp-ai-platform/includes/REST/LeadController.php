<?php
if (!defined('ABSPATH')) exit;
class WPAI_Lead_Controller {
    public static function init() { add_action('rest_api_init', [__CLASS__, 'routes']); }

    public static function routes() {
        register_rest_route('wp-ai/v1', '/leads', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [__CLASS__, 'create'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function create(WP_REST_Request $request) {
        global $wpdb;
        $data = [
            'name' => sanitize_text_field($request->get_param('name')),
            'email' => sanitize_email($request->get_param('email')),
            'phone' => sanitize_text_field($request->get_param('phone')),
            'source' => sanitize_text_field($request->get_param('source') ?: 'ai-chat'),
            'status' => 'new',
            'score' => absint($request->get_param('score')),
            'notes' => sanitize_textarea_field($request->get_param('notes')),
            'created_at' => current_time('mysql', true),
            'updated_at' => current_time('mysql', true),
        ];
        if ($data['email'] && !is_email($data['email'])) {
            return new WP_Error('invalid_email', 'Invalid email address.', ['status' => 400]);
        }
        $t = WPAI_Schema::tables()['leads'];
        $ok = $wpdb->insert($t, $data);
        if (!$ok) return new WP_Error('db_error', 'Could not create lead.', ['status' => 500]);
        WPAI_AuditLogger::log('lead_created', 'lead', $wpdb->insert_id);
        return new WP_REST_Response(['success' => true, 'id' => (int)$wpdb->insert_id], 201);
    }
}
