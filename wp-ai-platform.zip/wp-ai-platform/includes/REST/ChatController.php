<?php
if (!defined('ABSPATH')) exit;
class WPAI_Chat_Controller {
    public static function init() { add_action('rest_api_init', [__CLASS__, 'routes']); }

    public static function routes() {
        register_rest_route('wp-ai/v1', '/chat', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [__CLASS__, 'chat'],
            'permission_callback' => '__return_true',
            'args' => [
                'message' => ['required' => true, 'sanitize_callback' => 'sanitize_textarea_field'],
                'history' => ['required' => false],
            ],
        ]);
    }

    public static function chat(WP_REST_Request $request) {
        $settings = get_option('wpai_settings', []);
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
        $limit = absint($settings['rate_limit'] ?? 30);
        if (!WPAI_RateLimiter::allow('chat:' . $ip, max(1, $limit), 60)) {
            return new WP_Error('rate_limited', 'Too many requests. Please try again later.', ['status' => 429]);
        }

        $message = $request->get_param('message');
        if (strlen($message) > 5000) {
            return new WP_Error('message_too_long', 'Message exceeds the 5000 character limit.', ['status' => 400]);
        }

        $result = WPAI_Agent::respond($message, (array)$request->get_param('history'));
        if (is_wp_error($result)) return $result;

        return new WP_REST_Response(['success' => true, 'reply' => $result['text']], 200);
    }
}
