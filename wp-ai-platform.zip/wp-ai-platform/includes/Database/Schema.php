<?php
if (!defined('ABSPATH')) exit;
class WPAI_Schema {
    public static function tables() {
        global $wpdb;
        $p = $wpdb->prefix;
        return [
            'conversations' => $p . 'wpai_conversations',
            'messages' => $p . 'wpai_messages',
            'leads' => $p . 'wpai_leads',
            'sources' => $p . 'wpai_knowledge_sources',
            'chunks' => $p . 'wpai_knowledge_chunks',
            'usage' => $p . 'wpai_usage',
            'audit' => $p . 'wpai_audit_logs',
        ];
    }

    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $t = self::tables();

        $sql = [];
        $sql[] = "CREATE TABLE {$t['conversations']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NULL,
            session_id VARCHAR(64) NOT NULL,
            title VARCHAR(255) NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'open',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY user_id (user_id),
            KEY status (status)
        ) $charset;";

        $sql[] = "CREATE TABLE {$t['messages']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conversation_id BIGINT UNSIGNED NOT NULL,
            role VARCHAR(20) NOT NULL,
            content LONGTEXT NOT NULL,
            tokens INT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY conversation_id (conversation_id)
        ) $charset;";

        $sql[] = "CREATE TABLE {$t['leads']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NULL,
            email VARCHAR(190) NULL,
            phone VARCHAR(50) NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'new',
            score INT NOT NULL DEFAULT 0,
            source VARCHAR(100) NULL,
            notes TEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY email (email),
            KEY status (status)
        ) $charset;";

        $sql[] = "CREATE TABLE {$t['sources']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            type VARCHAR(30) NOT NULL,
            title VARCHAR(255) NOT NULL,
            source_url TEXT NULL,
            content LONGTEXT NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'pending',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY type (type),
            KEY status (status)
        ) $charset;";

        $sql[] = "CREATE TABLE {$t['chunks']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source_id BIGINT UNSIGNED NOT NULL,
            chunk_index INT UNSIGNED NOT NULL,
            content LONGTEXT NOT NULL,
            hash CHAR(64) NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY source_id (source_id),
            KEY hash (hash)
        ) $charset;";

        $sql[] = "CREATE TABLE {$t['usage']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            provider VARCHAR(50) NOT NULL,
            model VARCHAR(100) NULL,
            endpoint VARCHAR(100) NULL,
            tokens_in INT UNSIGNED NULL,
            tokens_out INT UNSIGNED NULL,
            duration_ms INT UNSIGNED NULL,
            status VARCHAR(30) NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY provider (provider),
            KEY created_at (created_at)
        ) $charset;";

        $sql[] = "CREATE TABLE {$t['audit']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NULL,
            action VARCHAR(100) NOT NULL,
            object_type VARCHAR(50) NULL,
            object_id BIGINT UNSIGNED NULL,
            meta LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY action (action),
            KEY created_at (created_at)
        ) $charset;";

        foreach ($sql as $statement) dbDelta($statement);
        update_option('wpai_db_version', WPAI_VERSION);
    }
}
