<?php
if (!defined('ABSPATH')) exit;
class WPAI_Dashboard {
    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_init', [__CLASS__, 'settings']);
    }

    public static function menu() {
        add_menu_page('WP AI Platform', 'WP AI Platform', 'manage_options', 'wp-ai-platform', [__CLASS__, 'page'], 'dashicons-format-chat', 58);
    }

    public static function settings() {
        register_setting('wpai_settings_group', 'wpai_settings', [
            'sanitize_callback' => function($input) {
                return [
                    'provider' => in_array($input['provider'] ?? 'gemini', ['gemini','openai'], true) ? $input['provider'] : 'gemini',
                    'gemini_api_key' => sanitize_text_field($input['gemini_api_key'] ?? ''),
                    'openai_api_key' => sanitize_text_field($input['openai_api_key'] ?? ''),
                    'model' => sanitize_text_field($input['model'] ?? 'gemini-2.5-flash'),
                    'system_prompt' => sanitize_textarea_field($input['system_prompt'] ?? ''),
                    'rate_limit' => max(1, absint($input['rate_limit'] ?? 30)),
                ];
            }
        ]);
    }

    public static function page() {
        if (!current_user_can('manage_options')) return;
        $s = get_option('wpai_settings', []);
        global $wpdb;
        $t = WPAI_Schema::tables();
        $leads = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['leads']}");
        $sources = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['sources']}");
        $usage = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['usage']}");
        ?>
        <div class="wrap wpai-admin">
            <h1>WP AI Platform</h1>
            <div class="wpai-cards">
                <div><strong><?php echo esc_html($leads); ?></strong><span>Leads</span></div>
                <div><strong><?php echo esc_html($sources); ?></strong><span>Knowledge Sources</span></div>
                <div><strong><?php echo esc_html($usage); ?></strong><span>AI Requests</span></div>
            </div>

            <h2>AI Provider Settings</h2>
            <form method="post" action="options.php">
                <?php settings_fields('wpai_settings_group'); ?>
                <table class="form-table">
                    <tr><th>Provider</th><td><select name="wpai_settings[provider]">
                        <option value="gemini" <?php selected($s['provider'] ?? '', 'gemini'); ?>>Google Gemini</option>
                        <option value="openai" <?php selected($s['provider'] ?? '', 'openai'); ?>>OpenAI</option>
                    </select></td></tr>
                    <tr><th>Gemini API Key</th><td><input type="password" class="regular-text" name="wpai_settings[gemini_api_key]" value="<?php echo esc_attr($s['gemini_api_key'] ?? ''); ?>" autocomplete="off"></td></tr>
                    <tr><th>OpenAI API Key</th><td><input type="password" class="regular-text" name="wpai_settings[openai_api_key]" value="<?php echo esc_attr($s['openai_api_key'] ?? ''); ?>" autocomplete="off"></td></tr>
                    <tr><th>Model</th><td><input class="regular-text" name="wpai_settings[model]" value="<?php echo esc_attr($s['model'] ?? 'gemini-2.5-flash'); ?>"></td></tr>
                    <tr><th>System Prompt</th><td><textarea class="large-text" rows="5" name="wpai_settings[system_prompt]"><?php echo esc_textarea($s['system_prompt'] ?? ''); ?></textarea></td></tr>
                    <tr><th>Rate Limit / minute</th><td><input type="number" min="1" name="wpai_settings[rate_limit]" value="<?php echo esc_attr($s['rate_limit'] ?? 30); ?>"></td></tr>
                </table>
                <?php submit_button('Save AI Settings'); ?>
            </form>

            <h2>REST API</h2>
            <p><code><?php echo esc_html(rest_url('wp-ai/v1/chat')); ?></code></p>
            <p>Use <code>POST</code> with <code>{"message":"Hello"}</code>.</p>
            <p><strong>Security note:</strong> API keys are stored in WordPress options and are never exposed to frontend JavaScript.</p>
        </div>
        <?php
    }
}
