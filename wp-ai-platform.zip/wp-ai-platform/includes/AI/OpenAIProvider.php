<?php
if (!defined('ABSPATH')) exit;
class WPAI_OpenAI_Provider implements WPAI_AI_Provider_Interface {
    public function chat(array $messages, array $options = []) {
        $settings = get_option('wpai_settings', []);
        $key = trim((string)($settings['openai_api_key'] ?? ''));
        $model = sanitize_text_field($options['model'] ?? 'gpt-4o-mini');
        if (!$key) return new WP_Error('missing_api_key', 'OpenAI API key is not configured.', ['status' => 500]);

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
            'timeout' => 45,
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $key,
            ],
            'body' => wp_json_encode([
                'model' => $model,
                'messages' => $messages,
                'temperature' => 0.2,
            ]),
        ]);
        if (is_wp_error($response)) return $response;
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300) {
            return new WP_Error('openai_error', $body['error']['message'] ?? 'OpenAI request failed.', ['status' => $code]);
        }
        return [
            'text' => $body['choices'][0]['message']['content'] ?? '',
            'raw' => $body,
        ];
    }
}
