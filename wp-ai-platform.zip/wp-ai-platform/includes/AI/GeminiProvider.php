<?php
if (!defined('ABSPATH')) exit;
class WPAI_Gemini_Provider implements WPAI_AI_Provider_Interface {
    public function chat(array $messages, array $options = []) {
        $settings = get_option('wpai_settings', []);
        $key = trim((string)($settings['gemini_api_key'] ?? ''));
        $model = sanitize_text_field($options['model'] ?? ($settings['model'] ?? 'gemini-2.5-flash'));
        if (!$key) return new WP_Error('missing_api_key', 'Gemini API key is not configured.', ['status' => 500]);

        $parts = [];
        foreach ($messages as $m) {
            $parts[] = ['text' => strtoupper($m['role']) . ": " . $m['content']];
        }

        $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($key);
        $response = wp_remote_post($url, [
            'timeout' => 45,
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode(['contents' => [['parts' => $parts]]]),
        ]);
        if (is_wp_error($response)) return $response;

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300) {
            return new WP_Error('gemini_error', $body['error']['message'] ?? 'Gemini request failed.', ['status' => $code]);
        }

        $text = $body['candidates'][0]['content']['parts'][0]['text'] ?? '';
        return ['text' => $text, 'raw' => $body];
    }
}
