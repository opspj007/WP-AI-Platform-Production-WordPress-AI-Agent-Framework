<?php
if (!defined('ABSPATH')) exit;
class WPAI_Agent {
    public static function respond($user_message, $history = []) {
        $settings = get_option('wpai_settings', []);
        $system = wp_strip_all_tags($settings['system_prompt'] ?? 'You are a helpful AI assistant.');
        $messages = [['role' => 'system', 'content' => $system]];
        foreach (array_slice((array)$history, -12) as $item) {
            if (!empty($item['role']) && isset($item['content'])) {
                $role = in_array($item['role'], ['user','assistant','system'], true) ? $item['role'] : 'user';
                $messages[] = ['role' => $role, 'content' => wp_strip_all_tags($item['content'])];
            }
        }
        $messages[] = ['role' => 'user', 'content' => wp_strip_all_tags($user_message)];

        $provider = WPAI_Provider_Factory::make();
        $start = microtime(true);
        $result = $provider->chat($messages);
        $duration = (int)((microtime(true) - $start) * 1000);

        global $wpdb;
        $t = WPAI_Schema::tables()['usage'];
        $wpdb->insert($t, [
            'provider' => get_class($provider),
            'model' => $settings['model'] ?? '',
            'endpoint' => 'chat',
            'duration_ms' => $duration,
            'status' => is_wp_error($result) ? 'error' : 'success',
            'created_at' => current_time('mysql', true),
        ]);

        return $result;
    }
}
