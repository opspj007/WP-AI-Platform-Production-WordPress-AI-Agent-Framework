<?php
if (!defined('ABSPATH')) exit;
class WPAI_Tool_Registry {
    private static $tools = [];
    public static function register($name, callable $callback, array $schema = []) {
        self::$tools[sanitize_key($name)] = ['callback' => $callback, 'schema' => $schema];
    }
    public static function all() { return self::$tools; }
    public static function call($name, array $args = []) {
        $name = sanitize_key($name);
        if (empty(self::$tools[$name])) return new WP_Error('tool_not_found', 'Tool not registered.');
        return call_user_func(self::$tools[$name]['callback'], $args);
    }
}
