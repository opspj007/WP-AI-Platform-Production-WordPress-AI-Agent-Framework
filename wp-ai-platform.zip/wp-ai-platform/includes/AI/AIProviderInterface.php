<?php
if (!defined('ABSPATH')) exit;
interface WPAI_AI_Provider_Interface {
    public function chat(array $messages, array $options = []);
}
