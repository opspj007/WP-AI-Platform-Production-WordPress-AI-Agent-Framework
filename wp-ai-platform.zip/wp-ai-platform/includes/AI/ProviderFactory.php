<?php
if (!defined('ABSPATH')) exit;
class WPAI_Provider_Factory {
    public static function make() {
        $settings = get_option('wpai_settings', []);
        $provider = $settings['provider'] ?? 'gemini';
        return $provider === 'openai'
            ? new WPAI_OpenAI_Provider()
            : new WPAI_Gemini_Provider();
    }
}
