<?php
if (!defined('ABSPATH')) exit;
class WPAI_Activator {
    public static function activate() {
        WPAI_Schema::install();
        if (get_option('wpai_settings') === false) {
            add_option('wpai_settings', [
                'provider' => 'gemini',
                'gemini_api_key' => '',
                'openai_api_key' => '',
                'model' => 'gemini-2.5-flash',
                'system_prompt' => 'You are a helpful website support AI assistant.',
                'rate_limit' => 30,
            ]);
        }
        flush_rewrite_rules();
    }
}
