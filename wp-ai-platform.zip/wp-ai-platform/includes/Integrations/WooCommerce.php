<?php
if (!defined('ABSPATH')) exit;
class WPAI_WooCommerce {
    public static function init() {
        if (!class_exists('WooCommerce')) return;
        add_action('init', [__CLASS__, 'register_tools']);
    }

    public static function register_tools() {
        WPAI_Tool_Registry::register('get_product', function($args) {
            $id = absint($args['product_id'] ?? 0);
            $product = $id ? wc_get_product($id) : false;
            if (!$product) return new WP_Error('not_found', 'Product not found.');
            return [
                'id' => $product->get_id(),
                'name' => $product->get_name(),
                'price' => $product->get_price(),
                'stock_status' => $product->get_stock_status(),
                'url' => $product->get_permalink(),
            ];
        }, [
            'type' => 'object',
            'properties' => ['product_id' => ['type' => 'integer']],
        ]);
    }
}
