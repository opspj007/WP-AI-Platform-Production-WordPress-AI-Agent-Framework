<?php
if (!defined('ABSPATH')) exit;
class WPAI_AuditLogger {
    public static function log($action, $object_type = '', $object_id = 0, $meta = []) {
        global $wpdb;
        $t = WPAI_Schema::tables()['audit'];
        $wpdb->insert($t, [
            'user_id' => get_current_user_id() ?: null,
            'action' => sanitize_key($action),
            'object_type' => sanitize_key($object_type),
            'object_id' => absint($object_id),
            'meta' => wp_json_encode($meta),
            'created_at' => current_time('mysql', true),
        ]);
    }
}
