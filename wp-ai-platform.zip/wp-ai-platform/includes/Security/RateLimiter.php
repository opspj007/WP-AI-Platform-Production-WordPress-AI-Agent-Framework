<?php
if (!defined('ABSPATH')) exit;
class WPAI_RateLimiter {
    public static function allow($key, $limit = 30, $window = 60) {
        $bucket = 'wpai_rl_' . md5($key . floor(time() / $window));
        $count = (int) get_transient($bucket);
        if ($count >= $limit) return false;
        set_transient($bucket, $count + 1, $window + 5);
        return true;
    }
}
