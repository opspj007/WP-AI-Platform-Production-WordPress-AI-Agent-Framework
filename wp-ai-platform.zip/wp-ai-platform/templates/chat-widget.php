<?php if (!defined('ABSPATH')) exit; ?>
<div data-wpai-chat aria-label="AI support chat"></div>
