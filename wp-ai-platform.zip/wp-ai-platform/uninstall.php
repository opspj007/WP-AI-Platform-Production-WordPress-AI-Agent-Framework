<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
global $wpdb;
$tables = [
    $wpdb->prefix.'wpai_conversations',
    $wpdb->prefix.'wpai_messages',
    $wpdb->prefix.'wpai_leads',
    $wpdb->prefix.'wpai_knowledge_sources',
    $wpdb->prefix.'wpai_knowledge_chunks',
    $wpdb->prefix.'wpai_usage',
    $wpdb->prefix.'wpai_audit_logs',
];
foreach ($tables as $table) $wpdb->query("DROP TABLE IF EXISTS {$table}");
delete_option('wpai_settings');
delete_option('wpai_db_version');
