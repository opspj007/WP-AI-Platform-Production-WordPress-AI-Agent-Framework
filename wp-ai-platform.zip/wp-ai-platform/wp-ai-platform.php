<?php
/**
 * Plugin Name: WP AI Platform
 * Description: Production-oriented WordPress AI platform with chat, leads, knowledge sources, REST APIs, usage logging, rate limiting and provider abstraction.
 * Version: 1.0.0
 * Author: Senior WordPress Engineering Demo
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: wp-ai-platform
 */
if (!defined('ABSPATH')) exit;

define('WPAI_VERSION', '1.0.0');
define('WPAI_FILE', __FILE__);
define('WPAI_DIR', plugin_dir_path(__FILE__));
define('WPAI_URL', plugin_dir_url(__FILE__));

require_once WPAI_DIR . 'includes/Core/Activator.php';
require_once WPAI_DIR . 'includes/Core/Deactivator.php';
require_once WPAI_DIR . 'includes/Database/Schema.php';
require_once WPAI_DIR . 'includes/Security/RateLimiter.php';
require_once WPAI_DIR . 'includes/Security/AuditLogger.php';
require_once WPAI_DIR . 'includes/AI/AIProviderInterface.php';
require_once WPAI_DIR . 'includes/AI/GeminiProvider.php';
require_once WPAI_DIR . 'includes/AI/OpenAIProvider.php';
require_once WPAI_DIR . 'includes/AI/ProviderFactory.php';
require_once WPAI_DIR . 'includes/AI/ToolRegistry.php';
require_once WPAI_DIR . 'includes/AI/Agent.php';
require_once WPAI_DIR . 'includes/REST/ChatController.php';
require_once WPAI_DIR . 'includes/REST/LeadController.php';
require_once WPAI_DIR . 'includes/REST/KnowledgeController.php';
require_once WPAI_DIR . 'includes/Admin/Dashboard.php';
require_once WPAI_DIR . 'includes/Integrations/WooCommerce.php';

register_activation_hook(__FILE__, ['WPAI_Activator', 'activate']);
register_deactivation_hook(__FILE__, ['WPAI_Deactivator', 'deactivate']);

final class WPAI_Plugin {
    private static $instance;

    public static function instance() {
        return self::$instance ?: (self::$instance = new self());
    }

    private function __construct() {
        add_action('plugins_loaded', [$this, 'boot']);
    }

    public function boot() {
        WPAI_Dashboard::init();
        WPAI_Chat_Controller::init();
        WPAI_Lead_Controller::init();
        WPAI_Knowledge_Controller::init();
        WPAI_WooCommerce::init();
        add_action('wp_enqueue_scripts', [$this, 'frontend_assets']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
    }

    public function frontend_assets() {
        wp_enqueue_style('wpai-chat', WPAI_URL . 'assets/css/chat.css', [], WPAI_VERSION);
        wp_enqueue_script('wpai-chat', WPAI_URL . 'assets/js/chat.js', [], WPAI_VERSION, true);
        wp_localize_script('wpai-chat', 'WPAI', [
            'restUrl' => esc_url_raw(rest_url('wp-ai/v1')),
            'nonce' => wp_create_nonce('wp_rest'),
        ]);
    }

    public function admin_assets($hook) {
        if (strpos($hook, 'wp-ai-platform') === false) return;
        wp_enqueue_style('wpai-admin', WPAI_URL . 'assets/css/admin.css', [], WPAI_VERSION);
    }
}
WPAI_Plugin::instance();
