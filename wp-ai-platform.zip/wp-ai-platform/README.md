# WP AI Platform

Production-oriented WordPress AI plugin starter.

## Features

- Gemini and OpenAI provider abstraction
- AI chat REST API
- AI support widget
- Lead collection API
- Knowledge source ingestion + chunking
- Custom database tables
- Usage logging
- Audit logging
- Rate limiting
- WooCommerce product tool
- WordPress admin dashboard
- Secure server-side API keys
- Extensible tool registry

## Installation

1. WordPress Admin → Plugins → Add New → Upload Plugin.
2. Upload `wp-ai-platform.zip`.
3. Activate.
4. Open **WP AI Platform** in the WordPress admin.
5. Configure an AI provider and API key.

## Chat widget

Add this HTML to a page/template:

```html
<div data-wpai-chat></div>
```

## REST endpoints

`POST /wp-json/wp-ai/v1/chat`

```json
{"message":"What services do you offer?"}
```

`POST /wp-json/wp-ai/v1/leads`

```json
{"name":"John","email":"john@example.com","phone":"+911234567890"}
```

`POST /wp-json/wp-ai/v1/knowledge`

Requires an authenticated administrator.

```json
{"title":"Company FAQ","content":"Our business provides..."}
```

## Production hardening

Before public SaaS deployment, add persistent vector storage/embeddings, asynchronous queues, document parsers, malware scanning for uploads, stronger per-user quotas, observability, automated tests, secret management, and a privacy/retention policy.
