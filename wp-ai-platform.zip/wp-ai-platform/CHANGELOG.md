# Changelog

## 1.0.0
- Initial production-oriented architecture
- Gemini/OpenAI providers
- REST chat, leads and knowledge APIs
- Admin settings/dashboard
- Custom database schema
- Rate limiting and audit logging
- WooCommerce tool registry
